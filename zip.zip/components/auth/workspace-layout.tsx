import { SessionProvider } from "./session-provider";
import { AppProviders } from "@/components/providers/app-providers";
import { AppShell } from "@/components/shell/app-shell";
import { requirePageAccess } from "@/lib/server/auth";
import type { AppModule } from "@/types/auth";
export async function WorkspaceLayout({
  module,
  children,
}: {
  module: AppModule;
  children: React.ReactNode;
}) {
  const user = await requirePageAccess(module);
  return (
    <SessionProvider user={user}>
      <AppProviders>
        <AppShell>{children}</AppShell>
      </AppProviders>
    </SessionProvider>
  );
}
